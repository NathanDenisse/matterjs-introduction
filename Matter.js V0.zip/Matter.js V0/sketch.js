// créer des alias pour les modules

function setup() {
  createCanvas(windowWidth, windowHeight * 0.8);
  //Créer un moteur pour le monde

  //Créer le monde

  //Créer des objets

  // mettre le corps dans le monde
}

function draw() {
  background(200);
}
